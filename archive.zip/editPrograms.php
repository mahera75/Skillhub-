<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>SkillHubOnlinePlatformForSelf-PacedShortCourses</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/sb-admin.css" rel="stylesheet">
    <link href="css/plugins/morris.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

</head>
<body>

    <div id="wrapper">

        <!-- Navigation -->
         <!-- The navigation will be inserted here -->

        <div id="page-wrapper">
            <div class="container-fluid">
                
<?php


include 'include/connection.php';


	$id=$_GET['id'];
	$result = mysqli_query($conn, "SELECT * FROM Programs where id='$id'");
		while($row = mysqli_fetch_array($result))
			{
			$ProgramsTitle = $row['ProgramsTitle'];
			$EligibilityCriteria = $row['EligibilityCriteria'];
			$Type = $row['Type'];
			$Duration = $row['Duration'];
			$Fee = $row['Fee'];
			$PreRequisite = $row['PreRequisite'];
			 
			}
?>
 
    <?php include("include/CourseCreatorNev.php"); ?>
     
  
  <div class="container">
    <div class="row">
      <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 hidden-xs">
        <div>
<form method="post" action="EditQueryPrograms.php">
  <input type="hidden" name="prodid" value="<?php echo @$id=$_GET['id'] ?>">
  <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">&nbsp;&nbsp;Input Data to Update Programs</h4>
         
        </div>
		
		
        <div class="modal-body">
		
		<div class="form-group">
                  <label for="pwd" >ProgramsTitle</label>
                  <div class="input-group">
				   
				   <input type="text" class="form-control" id="ProgramsTitle" name="ProgramsTitle" value="<?php echo $ProgramsTitle  ?>" required />
               </div>
			   </div>
			   
               <div class="form-group">
                  <label for="usr">EligibilityCriteria</label>
                   <div class="input-group">
				   
				      <textarea class="form-control" id="usr" name="EligibilityCriteria" cols="4" rows="3"><?php echo $EligibilityCriteria  ?></textarea>
					  
					  
				   
               </div>
			   </div>
			   
			   
			   <div class="form-group">
                  <label for="pwd" >Type</label>
                  <div class="input-group">
				   
				   	   <select class="form-control" id="Type" name="Type" >
  <option value="ShortCourses">ShortCourses</option>
  <option value="Diploma">Diploma</option>
 <option value="CompletePrograms ">Complete Programs </option>
</select>
			
				  
               </div>
			   </div>
	 
			 <div class="form-group">
                  <label for="pwd" >Duration</label>
                  <div class="input-group">
				   
				 <input type="text" class="form-control"   name="Duration" value="<?php echo $Duration  ?>" required />
               </div>
			   </div>
			 
			   
			   
			   
			   
			    <div class="form-group">
                  <label for="pwd" >Fee</label>
                  <div class="input-group">
				   
				   <input type="number" class="form-control" id="Fee" name="Fee" value="<?php echo $Fee  ?>" required />
               </div>
			   </div>
			 
			    <div class="form-group">
                  <label for="pwd" >PreRequisite</label>
                  <div class="input-group">
				   
				   <input type="text" class="form-control" id="PreRequisite" name="PreRequisite" value="<?php echo $PreRequisite  ?>" required />
               </div>
			   </div>
		 
			
			 
			   
			   <div class="modal-footer">
          <div class="row"> 
              <div class="col-md-12 "> 
					<button id="btn" name="btn" class="btn btn-primary">Submit</button>
		
		     </div>
		  
         </div>
      
              </div>
   
</form>
</div>
      </div>
    </div>
    
  </div>
 <!-- Dynamic content goes here -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

</body>
</html>