<?php

include 'include/connection.php';

{
$id=$_GET['id'];
 $sql = "delete from assignmentsolution where id='$id'";
 mysqli_query($conn, $sql);
}
	
	
	header("location: ManageAssignmentSolution.php");
?>