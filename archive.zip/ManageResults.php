<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>SkillHubOnlinePlatformForSelf-PacedShortCourses</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/sb-admin.css" rel="stylesheet">
    <link href="css/plugins/morris.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

</head>
<body>

    <div id="wrapper">

        <!-- Navigation -->
         <!-- The navigation will be inserted here -->

        <div id="page-wrapper">
            <div class="container-fluid">
                
<?php


include 'include/connection.php';

if(isset($_POST['btn']))
{
    
	$Student = $_POST['Student'];
	
	$ExamType = $_POST['ExamType'];
	$TotalMarks =$_POST['TotalMarks'];
	$ObtainedMarks =$_POST['ObtainedMarks'];
 
 $date =date("Y/m/d");
 
	if(mysqli_query($conn,"INSERT INTO Results(Student,ExamType,TotalMarks,ObtainedMarks,date ) VALUES('$Student','$ExamType','$TotalMarks','$ObtainedMarks','$date' )"))
	{
		?>
        <script>alert('successfully done ');</script>
        <?php
	}
	else
	{
		?>
        <script>alert('error while input data...');</script>
        <?php
	}
}
?> 
    <?php include("include/CourseCreatorNev.php"); ?>
     
  
  <div class="container">
    <div class="row">
      <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 hidden-xs">
        <div>
		 <div class="panel panel-danger" >
      <div class="panel-heading text-center" ><h4>&nbsp;&nbsp;Manage Results  LIST</h4></div>
<div class="panel-body">
<!-- 5555555555-->
<form method="post" >
  
  <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">&nbsp;&nbsp;Inpute Data For Results </h4>
         
        </div>
		
		
        <div class="modal-body">
		
		<div class="form-group">
                  <label for="pwd" >Student</label>
                  <div class="input-group">
				   <span class="input-group-addon"><span class="glyphicon glyphicon-lock"></span></span>
				    <table>
<tr>
<td>
   <div>
   
 
		<select class="form-control" id="Student"  name="Student" required/><?php
		$ddl=mysqli_query($conn,"select * from studentprofile where status='approved'") ;
		  while($row=mysqli_fetch_array($ddl))
{ ?>
<option value="<?php print $row['Email']; ?>"><?php print $row['Email'];
?>
<?php
}?>

</table>
				   
				    
               </div>
			   </div>
			   
               <div class="form-group">
                  <label for="usr">ExamType</label>
                   <div class="input-group">
				   <span class="input-group-addon"><span class="glyphicon glyphicon-envelope"></span></span>
				   <input type="text" class="form-control" id="usr" name="ExamType" placeholder="Enter ExamType" required />
               </div>
			   </div>
			   
			   
			   <div class="form-group">
                  <label for="pwd" >TotalMarks</label>
                  <div class="input-group">
				   <span class="input-group-addon"><span class="glyphicon glyphicon-lock"></span></span>
				   <input type="number" class="form-control" id="TotalMarks" name="TotalMarks" placeholder="Enter TotalMarks" required />
               </div>
			   </div>
	 
			 <div class="form-group">
                  <label for="pwd" >ObtainedMarks</label>
                  <div class="input-group">
				   <span class="input-group-addon"><span class="glyphicon glyphicon-lock"></span></span>
				   <input type="number" class="form-control" id="ObtainedMarks" name="ObtainedMarks" placeholder="Enter  ObtainedMarks" required />
               </div>
			   </div>
			 
			   
			   
			   
			    
			
			 
			   
			   <div class="modal-footer">
          <div class="row"> 
              <div class="col-md-12 "> 
					<button id="btn" name="btn" class="btn btn-danger">Submit</button>
				
					 <button type="reset" class="btn btn-primary" value="Reset">Reset</button>
			       		
		  		
		     </div>
		  
         </div>
      
              </div>
   
</form>
                    </div>
</div>
      </div>
	  <table class="table table-bordered table-responsive">
						<thead>
							<tr  >
								<th  class="col-sm-1"> ID </th>
                                
								<th  class="col-sm-1"> Student </th>
									<th  class="col-sm-1"> ExamType </th>
									<th  class="col-sm-1"> TotalMarks </th>
									<th  class="col-sm-1"> ObtainedMarks </th>
									<th  class="col-sm-1"> date </th>
			 
								<th  class="col-sm-1"> Dell/Edit </th>
						
							</tr>
						</thead>
						<tbody>
						<?php
					 
							 
							$result = mysqli_query($conn,"SELECT * FROM Results");
							while($row = mysqli_fetch_array($result))
								{
	echo '<td class="col-sm-0">'.$row['id'].'</td>';
									echo '<td class="col-sm-2">'.$row['Student'].'</td>';
									echo '<td class="col-sm-2">'.$row['ExamType'].'</td>';
									echo '<td class="col-sm-2">'.$row['TotalMarks'].'</td>';
										echo '<td class="col-sm-2">'.$row['ObtainedMarks'].'</td>';
										echo '<td class="col-sm-2">'.$row['date'].'</td>';

									echo '<td class="col-sm-5  text-center"> <a class="btn btn-danger" href="DelResults.php?id='.$row['id'].'"><span class="glyphicon glyphicon-ban-circle" aria-hidden="true"></span>Delete</a> </div></td>';
									echo '</tr>';
								} 
	
							?> 
						</tbody>
					</table>
    </div></div>
    
  </div>
 <!-- Dynamic content goes here -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

</body>
</html>