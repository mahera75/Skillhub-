<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>SkillHubOnlinePlatformForSelf-PacedShortCourses</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/sb-admin.css" rel="stylesheet">
    <link href="css/plugins/morris.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

</head>
<body>

    <div id="wrapper">

        <!-- Navigation -->
         <!-- The navigation will be inserted here -->

        <div id="page-wrapper">
            <div class="container-fluid">
                
<?php


include 'include/connection.php';

 
?> 
    <?php include("include/CourseCreatorNev.php"); ?>
     
  
  <div class="container">
    <div class="row">
      <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 hidden-xs">
        <div>
		 <div class="panel panel-primary" >
      <div class="panel-heading text-center" ><h4>&nbsp;&nbsp; Detail  LIST Of students thos apply</h4></div>
<div class="panel-body">
<!-- 5555555555-->
 
                    </div>
</div>
      </div>
	  <table class="table table-bordered table-responsive">
						<thead>
							<tr  >
								
                                	<th  class="col-sm-1">ID </th>
								<th  class="col-sm-1"> ProgramsTitle </th>
									<th  class="col-sm-1"> StudentEmail </th>
									<th  class="col-sm-1"> Type </th>
									<th  class="col-sm-1"> Duration </th>
									<th  class="col-sm-1"> Fee </th>
									<th  class="col-sm-1"> Status </th>
						 <th  class="col-sm-1"> Action </th>
							 
			 
							 
							</tr>
						</thead>
						<tbody>
						<?php
					  
							$result = mysqli_query($conn,"SELECT * FROM AppliedList  where ccemail='$cc'");
							while($row = mysqli_fetch_array($result))
								{
									
									echo '<td class="col-sm-0">'.$row['id'].'</td>';
									echo '<td class="col-sm-2">'.$row['ProgramsTitle'].'</td>';
									echo '<td class="col-sm-2">'.$row['StudentEmail'].'</td>';
									echo '<td class="col-sm-2">'.$row['Type'].'</td>';
										echo '<td class="col-sm-2">'.$row['Duration'].'</td>';
										echo '<td class="col-sm-2">'.$row['Fee'].'</td>';
										echo '<td class="col-sm-2">'.$row['Status'].'</td>';
					 
									 echo '<td class="col-sm-5  text-center"><a class="btn btn-primary" href="Accept.php?stdid='.$row['id'].'">accept</a>|<a class="btn btn-primary" href="Reject.php?stdid='.$row['id'].'">Reject</a> </div></td>';
				 
								 
									echo '</tr>';
								} 
	
							?> 
						</tbody>
					</table>
    </div></div>
    
  </div>
 <!-- Dynamic content goes here -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

</body>
</html>