<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>SkillHubOnlinePlatformForSelf-PacedShortCourses</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/sb-admin.css" rel="stylesheet">
    <link href="css/plugins/morris.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

</head>
<body>

    <div id="wrapper">

        <!-- Navigation -->
         <!-- The navigation will be inserted here -->

        <div id="page-wrapper">
            <div class="container-fluid">
                
 
<?php

 
include 'include/connection.php';
 
?>

    
    <?php include("include/CourseCreatorNev.php"); ?>
     
  
  <div class="container">
    <div class="row">
      <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 hidden-xs">
        <div>
		 <div class="panel panel-primary" >
      <div class="panel-heading text-center" ><h4>&nbsp;&nbsp;Evaluate Assignment Solution </h4></div>
<div class="panel-body">
<!-- 5555555555-->
 
                    </div>
</div>
      </div>
	  <table class="table table-bordered table-responsive">
						<thead>
							<tr  >
								<th  class="col-sm-1"> id </th>
                                <th  class="col-sm-1"> Subject </th>
								<th  class="col-sm-1"> SolutionFile </th>
									<th  class="col-sm-1"> StudentID </th>
									<th  class="col-sm-1"> TeachersRemarks </th>
									<th  class="col-sm-1"> ObtaindMarks </th>
		 
								<th  class="col-sm-1"> Evaluate </th>
						
							</tr>
						</thead>
						<tbody>
						<?php
					 
							 
							$result = mysqli_query($conn,"SELECT * FROM AssignmentSolution ");
							while($row = mysqli_fetch_array($result))
								{
									
									echo '<td class="col-sm-0">'.$row['id'].'</td>';
										echo '<td class="col-sm-0">'.$row['Subject'].'</td>';
									///file:///C:/wamp/www/Web-BasedAssignmentEvaluator/images/53431-Requirments%20.docx
									$encodedFileName = urlencode($row['SolutionFile']);
echo '<td class="col-sm-2"><a href="images/' . $encodedFileName . '" download>Download</a></td>';

								//	echo '<td class="col-sm-2"><a href="/images/'.$row['SolutionFile'].'" download>Download</a></td>';

									echo '<td class="col-sm-2">'.$row['StudentID'].'</td>';
									echo '<td class="col-sm-2">'.$row['TeachersRemarks'].'</td>';
										echo '<td class="col-sm-2">'.$row['ObtaindMarks'].'</td>';
						 
 
									
									echo '<td class="col-sm-5  text-center"> <a class="btn btn-primary" href="Evaluate.php?id='.$row['id'].'">Evaluate</a> </div></td>';
									echo '</tr>';
								} 
	
							?> 
						</tbody>
					</table>
    </div></div>
    
  </div> <!-- Dynamic content goes here -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

</body>
</html>