<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>SkillHubOnlinePlatformForSelf-PacedShortCourses</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/sb-admin.css" rel="stylesheet">
    <link href="css/plugins/morris.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

</head>
<body>

    <div id="wrapper">

        <!-- Navigation -->
         <!-- The navigation will be inserted here -->

        <div id="page-wrapper">
            <div class="container-fluid">
                
<?php

 
include 'include/connection.php';

		
if(isset($_POST['btn']))
{
    
	$ProgramsTitle = $_POST['ProgramsTitle'];
	
	$EligibilityCriteria = $_POST['EligibilityCriteria'];
	$Type =$_POST['Type'];
	$Duration =$_POST['Duration'];
 
 $Fee =$_POST['Fee'];
 $PreRequisite =$_POST['PreRequisite'];
 
 
	if(mysqli_query($conn,"INSERT INTO Programs(ProgramsTitle,EligibilityCriteria,Type,Duration,Fee,PreRequisite,ccemail ) VALUES('$ProgramsTitle','$EligibilityCriteria','$Type','$Duration','$Fee','$PreRequisite','$cc' )"))
	{
		?>
        <script>alert('successfully done ');</script>
        <?php
	}
	else
	{
		?>
        <script>alert('error while input data...');</script>
        <?php
	}
}
?> 
    <?php include("include/CourseCreatorNev.php"); ?>
     
  
  <div class="container">
    <div class="row">
      <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 hidden-xs">
        <div>
		 <div class="panel panel-primary" >
      <div class="panel-heading text-center" ><h4>&nbsp;&nbsp;Manage Programs  LIST</h4></div>
<div class="panel-body">
<!-- 5555555555-->
<form method="post" >
  
  <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">&nbsp;&nbsp;Input Data For Programs </h4>
         
        </div>
		
		
        <div class="modal-body">
		
		<div class="form-group">
                  <label for="pwd" >ProgramsTitle</label>
                  <div class="input-group">
				   
				   <input type="text" class="form-control" id="ProgramsTitle" name="ProgramsTitle" placeholder="Enter ProgramsTitle" required />
               </div>
			   </div>
			   
               <div class="form-group">
                  <label for="usr">EligibilityCriteria</label>
                    
				   
				   <textarea class="form-control" id="usr" name="EligibilityCriteria" cols="4" rows="3"></textarea>
				 
               
			   </div>
			   
			   
			   <div class="form-group">
                  <label for="pwd" >Type</label>
                  <div class="input-group">
				   
				   <select class="form-control" id="Type" name="Type" >
  <option value="web-development">Web Development</option>
        <option value="database-management">Database Management</option>
        <option value="user-authentication-security">User Authentication and Security</option>
        <option value="front-end-development">Front-end Development</option>
        <option value="back-end-development">Back-end Development</option>
        <option value="payment-processing">Payment Processing</option>
        <option value="collaboration-tools">Collaboration Tools</option>
        <option value="analytics-reporting">Analytics and Reporting</option>
        <option value="personalization-recommendation">Personalization and Recommendation Systems</option>
        <option value="project-management">Project Management and Software Development</option>
    
</select>
				 
               </div>
			   </div>
	 
			 <div class="form-group">
                  <label for="pwd" >Duration</label>
                  <div class="input-group">
				   
				   <input type="text" class="form-control" id="Duration" name="Duration" placeholder="Enter  Duration" required />
               </div>
			   </div>
			 
			   
			   
			   
			   
			    <div class="form-group">
                  <label for="pwd" >Fee</label>
                  <div class="input-group">
				   
				   <input type="number" class="form-control" id="Fee" name="Fee" placeholder="Enter  Fee" required />
               </div>
			   </div>
			 
			    <div class="form-group">
                  <label for="pwd" >PreRequisite</label>
                  <div class="input-group">
				   
				   <input type="text" class="form-control" id="PreRequisite" name="PreRequisite" placeholder="Enter PreRequisite" required />
               </div>
			   </div>
			 
			 
			 
			   
			   <div class="modal-footer">
          <div class="row"> 
              <div class="col-md-12 "> 
					<button id="btn" name="btn" class="btn btn-primary">Submit</button>
				
					 <button type="reset" class="btn btn-primary" value="Reset">Reset</button>
			       		
		  		
		     </div>
		  
         </div>
      
              </div>
   
</form>
                    </div>
</div>
      </div>
	  <table class="table table-bordered table-responsive">
						<thead>
							<tr  >
								
                                	<th  class="col-sm-1">ID </th>
								<th  class="col-sm-1"> ProgramsTitle </th>
									<th  class="col-sm-1"> EligibilityCriteria </th>
									<th  class="col-sm-1"> Type </th>
									<th  class="col-sm-1"> Duration </th>
									<th  class="col-sm-1"> Fee </th>
									<th  class="col-sm-1"> PreRequisite </th>
						 
								<th  class="col-sm-1"> Dell/Edit </th>
						
							</tr>
						</thead>
						<tbody>
						<?php
					  
							$result = mysqli_query($conn,"SELECT * FROM Programs where ccemail='$cc'");
							while($row = mysqli_fetch_array($result))
								{
									
									echo '<td class="col-sm-0">'.$row['id'].'</td>';
									echo '<td class="col-sm-2">'.$row['ProgramsTitle'].'</td>';
									echo '<td class="col-sm-2">'.$row['EligibilityCriteria'].'</td>';
									echo '<td class="col-sm-2">'.$row['Type'].'</td>';
										echo '<td class="col-sm-2">'.$row['Duration'].'</td>';
										echo '<td class="col-sm-2">'.$row['Fee'].'</td>';
										echo '<td class="col-sm-2">'.$row['PreRequisite'].'</td>';
					 
									
									echo '<td class="col-sm-5  text-center"><a class="btn btn-primary" href="editPrograms.php?id='.$row['id'].'">Edit</a>|<a class="btn btn-primary" href="DelPrograms.php?id='.$row['id'].'">Delete</a> </div></td>';
									echo '</tr>';
								} 
	
							?> 
						</tbody>
					</table>
    </div></div>
    
  </div>
 <!-- Dynamic content goes here -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

</body>
</html>