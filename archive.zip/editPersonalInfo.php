<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>SkillHubOnlinePlatformForSelf-PacedShortCourses</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/sb-admin.css" rel="stylesheet">
    <link href="css/plugins/morris.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

</head>
<body>

    <div id="wrapper">

        <!-- Navigation -->
         <!-- The navigation will be inserted here -->

        <div id="page-wrapper">
            <div class="container-fluid">
                
<?php


include 'include/connection.php';


	$id=$_GET['id'];
	$result = mysqli_query($conn, "SELECT * FROM PersonalInfo where id='$id'");
		while($row = mysqli_fetch_array($result))
			{
			$DreamsAndGoals = $row['DreamsAndGoals'];
			$InterestsAndValues = $row['InterestsAndValues'];
			$Skills = $row['Skills'];
			$Experience = $row['Experience'];
			$ExtraCurricular = $row['ExtraCurricular'];
		
		
			
			}
?>
 
    <?php include("include/StudentNev.php"); ?>
     
  
  <div class="container">
    <div class="row">
      <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 hidden-xs">
        <div>
<form method="post" action="EditQueryPersonalInfo.php">
  <input type="hidden" name="prodid" value="<?php echo @$id=$_GET['id'] ?>">
  <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">&nbsp;&nbsp;Input Data to Update</h4>
         
        </div>
		
		
        <div class="modal-body">
		
		<div class="form-group">
                  <label for="pwd" >DreamsAndGoals</label>
                  <div class="input-group">
				   
				   <input type="text" class="form-control" id="DreamsAndGoals" name="DreamsAndGoals" value="<?php echo $DreamsAndGoals  ?>" required />
               </div>
			   </div>
			   
               <div class="form-group">
                  <label for="usr">InterestsAndValues</label>
                   <div class="input-group">
				   
				   <input type="text" class="form-control" id="usr" name="InterestsAndValues" value="<?php echo $InterestsAndValues  ?>" required />
               </div>
			   </div>
			   
			   
			   <div class="form-group">
                  <label for="pwd" >Skills</label>
                  <div class="input-group">
				   
				   <input type="text" class="form-control" id="Skills" name="Skills" value="<?php echo $Skills  ?>" required />
               </div>
			   </div>
	 
			 <div class="form-group">
                  <label for="pwd" >Experience</label>
                  <div class="input-group">
				   
				   <input type="text" class="form-control" id="Experience" name="Experience" value="<?php echo $Experience  ?>" required />
               </div>
			   </div>
			 
			   
			   
			   
			   
			    <div class="form-group">
                  <label for="pwd" >ExtraCurricular</label>
                  <div class="input-group">
				   
				   <input type="text" class="form-control" id="ExtraCurricular" name="ExtraCurricular" value="<?php echo $ExtraCurricular  ?>" required />
               </div>
			   </div>

			   <div class="modal-footer">
          <div class="row"> 
              <div class="col-md-12 "> 
					<button id="btn" name="btn" class="btn btn-primary">Submit</button>
		
		     </div>
		  
         </div>
      
              </div>
   
</form>
</div>
      </div>
    </div>
    
  </div>
 <!-- Dynamic content goes here -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

</body>
</html>