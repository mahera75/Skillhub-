<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>SkillHubOnlinePlatformForSelf-PacedShortCourses</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/sb-admin.css" rel="stylesheet">
    <link href="css/plugins/morris.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

</head>
<body>

    <div id="wrapper">

        <!-- Navigation -->
         <!-- The navigation will be inserted here -->

        <div id="page-wrapper">
            <div class="container-fluid">
                
 
 
<?php
include 'include/connection.php';
 
 	$TeacherID=$_SESSION['EmailCC'];

?>
<?php
 
$result = mysqli_query($conn, "SELECT * FROM AssignmentSolution ");
while ($row = mysqli_fetch_array($result)) {
    $id = $row['id'];
    $subject = $row['Subject'];
	$onlyFileName=$row['SolutionFile'];
    $encodedFileName = urlencode($row['SolutionFile']);
	
    $downloadLink = 'images/' . $encodedFileName;
    $studentID = $row['StudentID'];
    $teachersRemarks = $row['TeachersRemarks'];
    $obtainedMarks = $row['ObtaindMarks'];
	}
	
    ?>
	<?php


 

 

if(isset($_POST['btn']))
{
    
	 
	$TeachersRemarks = $_POST['TeachersRemarks'];
 
 
 $ObtaindMarks= $_POST['ObtaindMarks'];
 
 
 $originalFile = 'images/' . $encodedFileName;
$newFile = 'images/' . 'Solution'.$encodedFileName; // The copy of the original file
$contentToAppend = ' 
Teachers Remarks "'.$_POST['TeachersRemarks'].'" Your Marks are ('.$ObtaindMarks.')

';
/*
// Read the original file content
$originalContent = file_get_contents($originalFile); // Append the new content to the original content
    $appendedContent = $originalContent . PHP_EOL . $contentToAppend; // Write the appended content to the new file
    $result = file_put_contents($newFile, $appendedContent);
 */
 
 
  // Get the content from the textarea
    $text_content = $contentToAppend.$_POST['text_content']; // Generate a unique filename (you can modify this as needed)
    $filename = 'SolutionFileFor' . $subject. $onlyFileName.$studentID.'.doc'; // Specify the directory where you want to save the file
    $save_directory = 'images/'; // Check if the directory exists; create it if not
    if (!is_dir($save_directory)) {
        mkdir($save_directory, 0777, true);
    } // Combine the directory and filename
    $file_path = $save_directory . $filename; // Write the content to the new text file
    if (file_put_contents($file_path, $text_content)) {
      //  echo "Text file '$filename' created successfully. <a href='$file_path' download>Download</a>";
    } else {
        echo "Error creating the text file.";
    }
 
	if(mysqli_query($conn,"UPDATE `assignmentsolution` SET `TeachersRemarks`='$TeachersRemarks',`ObtaindMarks`='$ObtaindMarks',`TeacherID`='$TeacherID',`MarkedFile`='$filename' WHERE `id`='$id'"))
	{
		?>
<script>
  alert('Successfully done');
  window.location.href = 'EvaluateAssignment.php';
</script>     <?php
	}
	else
	{
		?>
        <script>alert('error while input data...');</script>
        <?php
	}
}
?>

    
    <?php include("include/CourseCreatorNev.php"); ?>
     
  
  <div class="container">
    <div class="row">
      <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 hidden-xs">
        <div>
		 <div class="panel panel-primary" >
      <div class="panel-heading text-center" ><h4>&nbsp;&nbsp;Manage LIST</h4></div>
<div class="panel-body">
          
		 
		 
<h2>Subject Code : <?php echo $subject; ?></h2>
<h2>Solution Submited by Student : <?php echo $studentID; ?></h2>
<form method="post"   >

<?php
if (isset($_GET['id'])) {
    $id = $_GET['id'];
 
    $result = mysqli_query($conn, "SELECT * FROM AssignmentSolution WHERE id = $id");
    if ($row = mysqli_fetch_array($result)) {
        $docxFilePath = 'images/' . urlencode($row['SolutionFile']);     // Check if the file exists
        if (file_exists($docxFilePath)) {
            // Extract text content from the DOCX file
            $content = readDocx($docxFilePath);         // Display the content inside a <textarea> with line breaks
            echo '<!DOCTYPE html>
                    <html lang="en">
                    <head>
                        <meta charset="UTF-8">
                        <title>View Document</title>
                    </head>
                    <body>
                        <h1>Document Content</h1>
                        <textarea name="text_content" rows="18" cols="150">' . htmlspecialchars($content) . '</textarea>
                    </body>
                    </html>';
        } else {
            echo "File not found.";
        }
    } else {
        echo "Solution not found.";
    }
} else {
    echo "Invalid request.";
}

// Function to extract text content from a DOCX file
function readDocx($filename) {
    $content = ''; // Open the DOCX file as a ZIP archive
    $zip = new ZipArchive;
    if ($zip->open($filename) === true) {
        // Read the content from the 'word/document.xml' file
        $xmlContent = $zip->getFromName('word/document.xml');     // Extract and clean the text content
        $content = strip_tags($xmlContent);
        $content = str_replace('&nbsp;', ' ', $content);
        $content = html_entity_decode($content);
    } return $content;
}
?>

<!-- 5555555555-->

  
  <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">&nbsp;&nbsp;Input  Data For Assignment Evaluation</h4>
         
        </div>
		
	 



			 <div class="form-group">
                  <label for="pwd" >TeachersRemarks</label>
                  <div class="input-group">
				   <span class="input-group-addon"><span class="glyphicon glyphicon-lock"></span></span>
				   <input type="text" class="form-control" id="TeachersRemarks" name="TeachersRemarks" placeholder="Enter TeachersRemarks" required />
               </div>
			   </div>
			   
               <div class="form-group">
                  <label for="usr">ObtaindMarks</label>
                   <div class="input-group">
				   <span class="input-group-addon"><span class="glyphicon glyphicon-envelope"></span></span>
				   <input type="number" class="form-control" id="usr" name="ObtaindMarks" placeholder="Enter ObtaindMarks" required />
               </div>
			   </div>
			 
			
			 
			   
			   <div class="modal-footer">
          <div class="row"> 
              <div class="col-md-12 "> 
					<button id="btn" name="btn" class="btn btn-primary">Submit</button>
				
					 
			       		
		  		
		     </div>
		  
         </div>
      
              </div>
   
</form>
                    </div>
</div>
      </div>
	  
					 
    </div></div>
    
  </div> <!-- Dynamic content goes here -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

</body>
</html>