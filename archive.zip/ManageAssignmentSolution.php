<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>SkillHubOnlinePlatformForSelf-PacedShortCourses</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/sb-admin.css" rel="stylesheet">
    <link href="css/plugins/morris.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

</head>
<body>

    <div id="wrapper">

        <!-- Navigation -->
         <!-- The navigation will be inserted here -->

        <div id="page-wrapper">
            <div class="container-fluid">
                
 
<?php

include 'include/connection.php';

$Student=$_SESSION['EmailStd'];


if(isset($_POST['btn']))
{
    
 $Subject=$_POST['Subject'];
 
	 $SolutionFile = rand(1000,100000)."-".$_FILES['SolutionFile']['name']; 
    $file_loc = $_FILES['SolutionFile']['tmp_name']; 		
 $folder="images/";
move_uploaded_file($file_loc,$folder.$SolutionFile);
 
 
	if(mysqli_query($conn,"INSERT INTO `assignmentsolution`( `SolutionFile`, `StudentID`, `Subject`) VALUES ('$SolutionFile','$Student','$Subject')"))
	{
		?>
        <script>alert('successfully done ');</script>
        <?php
	}
	else
	{
		?>
        <script>alert('error while input data...');</script>
        <?php
	}
}
?>

    
    <?php include("include/StudentNev.php"); ?>
     
  
  <div class="container">
    <div class="row">
      <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 hidden-xs">
        <div>
		 <div class="panel panel-primary" >
      <div class="panel-heading text-center" ><h4>&nbsp;&nbsp;Manage  Assignment Solution Files</h4></div>
<div class="panel-body">
<!-- 5555555555-->
<form method="post"  enctype="multipart/form-data">
  
  <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">&nbsp;&nbsp;Input  Data For AssignmentSolution </h4>
         
        </div>
		
		
        <div class="modal-body">
		
		<div class="form-group">
                  <label for="pwd" >Select Questions File</label>
                  <div class="input-group">
				   
				    <input  class="form-control"   type="file" name="SolutionFile" placeholder="Enter Your product_name" required />
				   
               </div>
			   </div>
			   
          
			 
			    <div class="form-group">
                  <label for="usr">Subject</label>
                   <div class="input-group">
								    	   <table>
<tr>
<td>
   <div>
   
 
		<select class="form-control" id="Student" name="Subject"   required/><?php
		$ddl=mysqli_query($conn,"select * from Programs  ") ;
		  while($row=mysqli_fetch_array($ddl))
{ ?>
<option value="<?php print $row['ProgramsTitle']; ?>"><?php print $row['ProgramsTitle'];
?>
<?php
}?>

</table>
			 
               </div>
			   </div>
			   
			   
			   
		 
			 
			 
			
			 
			   
			   <div class="modal-footer">
          <div class="row"> 
              <div class="col-md-12 "> 
					<button id="btn" name="btn" class="btn btn-primary">Submit</button>
				
					 
			       		
		  		
		     </div>
		  
         </div>
      
              </div>
   
</form>
                    </div>
</div>
      </div>
	  <table class="table table-bordered table-responsive">
						<thead>
							<tr  >
								<th  class="col-sm-1"> id </th>
                                <th  class="col-sm-1"> Subject </th>
								<th  class="col-sm-1"> SolutionFile </th>
									<th  class="col-sm-1"> StudentID </th>
									<th  class="col-sm-1"> TeachersRemarks </th>
									<th  class="col-sm-1"> ObtaindMarks </th>
			 	<th  class="col-sm-1"> Download Marked File</th>
								<th  class="col-sm-1"> Dell/Edit </th>
						
							</tr>
						</thead>
						<tbody>
						<?php
					 
							$result = mysqli_query($conn,"SELECT * FROM AssignmentSolution where StudentID = '$Student'");
							while($row = mysqli_fetch_array($result))
								{
									
									echo '<td class="col-sm-0">'.$row['id'].'</td>';
										echo '<td class="col-sm-0">'.$row['Subject'].'</td>';
									///file:///C:/wamp/www/Web-BasedAssignmentEvaluator/images/53431-Requirments%20.docx
									$encodedFileName = urlencode($row['SolutionFile']);
echo '<td class="col-sm-2"><a href="images/' . $encodedFileName . '" download>Download</a></td>';

								//	echo '<td class="col-sm-2"><a href="/images/'.$row['SolutionFile'].'" download>Download</a></td>';

									echo '<td class="col-sm-2">'.$row['StudentID'].'</td>';
									echo '<td class="col-sm-2">'.$row['TeachersRemarks'].'</td>';
										echo '<td class="col-sm-2">'.$row['ObtaindMarks'].'</td>';
						 
									
											$encodedFileName = urlencode($row['MarkedFile']);
echo '<td class="col-sm-2"><a class="btn btn-danger" href="images/' . $encodedFileName . '" download>Download Marked File</a></td>';
									
									echo '<td class="col-sm-5  text-center"> <a class="btn btn-primary" href="DelAssignmentSolution.php?id='.$row['id'].'">Delete</a> </div></td>';
									echo '</tr>';
								} 
	
							?> 
						</tbody>
					</table>
    </div></div>
    
  </div> <!-- Dynamic content goes here -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

</body>
</html>