<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>SkillHubOnlinePlatformForSelf-PacedShortCourses</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/sb-admin.css" rel="stylesheet">
    <link href="css/plugins/morris.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<style>
.task {
    background-color:#FFCC66;
}

</style>
</head>
<body>

    <div id="wrapper">

        <!-- Navigation -->
         <!-- The navigation will be inserted here -->

        <div id="page-wrapper">
            <div class="container-fluid">
                


    <?php include("include/GenNev.php"); ?>
     
  
       <div class="container mt-5">
        <div class="row align-items-center">
            <!-- Image Section -->
            <div class="col-md-4">
                <img width="100%" height="100%" src="images\home.png" class="img-fluid rounded" alt="Education">
            </div>
            <!-- Text Section -->
            <div class="col-md-8">
                <h2 class="mb-3">The Importance of Education</h2>
                <p>
                    Education is the foundation upon which individuals build their futures. It fosters critical thinking, 
                    promotes social awareness, and equips people with the skills necessary to navigate the complexities of modern life. 
                    From early childhood to higher education, learning provides opportunities to explore, innovate, and achieve personal growth. 
                    In an increasingly interconnected world, education serves as a bridge between cultures, breaking down barriers and 
                    cultivating mutual understanding. Ultimately, education is not just a means to an end; it is a journey that empowers 
                    individuals to contribute meaningfully to society and pursue their dreams.
                </p>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS (optional, for interactivity) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  
  <!-- Dynamic content goes here -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

</body>
</html>