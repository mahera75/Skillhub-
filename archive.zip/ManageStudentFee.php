<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>SkillHubOnlinePlatformForSelf-PacedShortCourses</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/sb-admin.css" rel="stylesheet">
    <link href="css/plugins/morris.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

</head>
<body>

    <div id="wrapper">

        <!-- Navigation -->
         <!-- The navigation will be inserted here -->

        <div id="page-wrapper">
            <div class="container-fluid">
                
	<?php
			include 'include/connection.php';
		  
							$result = mysqli_query($conn,"SELECT * FROM AppliedList where  StudentEmail='$user' ");
							while($row = mysqli_fetch_array($result))
								{
									
			  
										$fee=$row['Fee'] ;
								   
								} 
	
							?> 
<?php



if(isset($_POST['btn']))
{
  
     $file = rand(1000,100000)."-".$_FILES['file']['name']; 
    $file_loc = $_FILES['file']['tmp_name']; 		
 $folder="images/";
move_uploaded_file($file_loc,$folder.$file);
	 
	
	$Month = $_POST['Month'];
 $FeeAmount = $_POST['FeeAmount'];
 $UserID = $_POST['UserID'];
 $key=$Month.$user;
	if(mysqli_query($conn,"INSERT INTO `studentfee`( `Student`, `Month`, `FeeAmount`, `key`, `file`, `CCUserID`) VALUES ('$user','$Month','$FeeAmount' ,'$key','$file','$UserID' )"))
	{
		?>
        <script>alert('successfully done ');</script>
        <?php
	}
	else
	{
		?>
        <script>alert('error because this month fee is already added...');</script>
        <?php
	}
}
?> 
    <?php include("include/StudentNev.php"); ?>
     
  
  <div class="container">
    <div class="row">
      <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 hidden-xs">
        <div>
		 <div class="panel panel-danger" >
      <div class="panel-heading text-center" ><h4>&nbsp;&nbsp;Manage StudentFee  LIST</h4></div>
<div class="panel-body">
<!-- 5555555555-->
<?php 
if (!isset($fee)) {
    echo "<h1>You are not enrolled in any program yet.</h1>";
} 
 


else {
?>
<form method="post"    enctype="multipart/form-data">
  
  <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">&nbsp;&nbsp;Input Data For StudentFee </h4>
         
        </div>
		
		
        <div class="modal-body">
		
		 
			   <div class="form-group">
                  <label for="pwd" >Paid vouchers image </label>
                  <div class="input-group">
				   <span class="input-group-addon"><span class="glyphicon glyphicon-lock"></span></span>
				   
				  

				   <input  class="form-control"   type="file" name="file" placeholder="Enter Your product_name" required />
               </div>
			   </div>
               <div class="form-group">
                  <label for="usr">Month</label>
                   <div class="input-group">
				   <span class="input-group-addon"><span class="glyphicon glyphicon-envelope"></span></span>
				   <input type="month" class="form-control" id="usr" name="Month" placeholder="Enter Month" required />
               </div>
			   </div>
			   
			   
			   <div class="form-group">
                  <label for="pwd" >FeeAmount</label>
                  <div class="input-group">
				   <span class="input-group-addon"><span class="glyphicon glyphicon-lock"></span></span>
				   <input type="number" class="form-control"    name="FeeAmount" placeholder="input Your Monthly fee " required />
               </div>
			   </div>
			 
			
			 	<div class="form-group">
                  <label for="pwd" >Fee To (Select Course Creator): </label>
                  <div class="input-group">
				   
				   

 
				  
<table>
<tr>
<td>
   <div>
   <?php
	 
$list=mysqli_query($conn,"SELECT * FROM `studentprofile` where UserType='CourseCreator'");
?>
 
		<select name="UserID" class="form-control" required/><?php

  while($row=mysqli_fetch_array($list))
{ ?>
<option value="<?php print $row['Email']; ?>"><?php print $row['Email'];
?>
<?php
}?> </option></select>

</table>

			 
               </div>
			   </div>
			 
			   
			  
			 
			   
			   <div class="modal-footer">
          <div class="row"> 
              <div class="col-md-12 "> 
					<button id="btn" name="btn" class="btn btn-danger">Submit</button>
				
					 <button type="reset" class="btn btn-primary" value="Reset">Reset</button>
			       		
		  		
		     </div>
		  
         </div>
      
              </div>
   
</form>
                    </div>
</div>
      </div>
	  
	  <table class="table table-bordered table-responsive">
						<thead>
							<tr  >
								
                                		<th  class="col-sm-1"> ID</th>
								<th  class="col-sm-1"> Student </th>
									<th  class="col-sm-1"> Month </th>
									<th  class="col-sm-1"> FeeAmount </th>
						 	<th  class="col-sm-1"> paid vouchers </th>
							<th  class="col-sm-1"> Course Creator</th>
								<th  class="col-sm-1"> Dell/Edit </th>
						
							</tr>
						</thead>
						<tbody>
						<?php
						 
							 
							$result = mysqli_query($conn,"SELECT * FROM StudentFee where Student='$user'");
							while($row = mysqli_fetch_array($result))
								{
									
									echo '<td class="col-sm-0">'.$row['id'].'</td>';
									echo '<td class="col-sm-2">'.$row['Student'].'</td>';
									echo '<td class="col-sm-2">'.$row['Month'].'</td>';
										echo '<td class="col-sm-2"><a href="images/'.$row['file'].'">Get Vouchers</a></td>';
									
									echo '<td class="col-sm-2">'.$row['FeeAmount'].'</td>';
 
										echo '<td class="col-sm-2">'.$row['CCUserID'].'</td>';
									
									echo '<td class="col-sm-5  text-center"> <a class="btn btn-danger" href="DelStudentFee.php?id='.$row['id'].'">Delete</a> </div></td>';
									echo '</tr>';
								} 
	
							?> 
						</tbody>
					</table>
					<?php 
 
} 
?>
    </div></div>
    
  </div>
 <!-- Dynamic content goes here -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

</body>
</html>