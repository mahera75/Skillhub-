<?php

include 'include/connection.php';

{
$id=$_GET['id'];
 $sql = "delete from assignments where id='$id'";
 mysqli_query($conn, $sql);
}
	
	
	header("location: Manageassignment.php");
?>