<?php
    session_start();
  {
        
      unset($_SESSION['EmailCC']);
 
 
                unset($_SESSION['EmailAdm']);
   unset($_SESSION['EmailStd']);
        header("location: index.php");
        exit;
            
    }
?>
