<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>SkillHubOnlinePlatformForSelf-PacedShortCourses</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/sb-admin.css" rel="stylesheet">
    <link href="css/plugins/morris.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

</head>
<body>

    <div id="wrapper">

        <!-- Navigation -->
         <!-- The navigation will be inserted here -->

        <div id="page-wrapper">
            <div class="container-fluid">
                
<?php


include 'include/connection.php';

if(isset($_POST['btn']))
{
    
	$Details = $_POST['Details'];
	
	$Date =  date("Y/m/d");
 
 
	if(mysqli_query($conn,"INSERT INTO Announcements(Details,Date ) VALUES('$Details','$Date' )"))
	{
		?>
        <script>alert('successfully done ');</script>
        <?php
	}
	else
	{
		?>
        <script>alert('error while input data...');</script>
        <?php
	}
}
?> 
    <?php include("include/CourseCreatorNev.php"); ?>
     
  
  <div class="container">
    <div class="row">
      <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 hidden-xs">
        <div>
		 <div class="panel panel-danger" >
      <div class="panel-heading text-center" ><h4>&nbsp;&nbsp;Manage Announcements  LIST</h4></div>
<div class="panel-body">
<!-- 5555555555-->
<form method="post" >
  
  <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">&nbsp;&nbsp;Inpute Data For Announcements </h4>
         
        </div>
		
		
        <div class="modal-body">
		
		<div class="form-group">
                  <label for="pwd" >Details</label>
                  <textarea  class="form-control"  name="Details" cols="6" rows="3"></textarea>
				 
            
			   </div>
			   
    
			   <div class="modal-footer">
          <div class="row"> 
              <div class="col-md-12 "> 
					<button id="btn" name="btn" class="btn btn-danger">Submit</button>
				
					 <button type="reset" class="btn btn-primary" value="Reset">Reset</button>
			       		
		  		
		     </div>
		  
         </div>
      
              </div>
   
</form>
                    </div>
</div>
      </div>
	  <table class="table table-bordered table-responsive">
						<thead>
							<tr >
								
                                	<th  class="col-sm-1"> ID </th>
								<th  class="col-sm-1"> Details </th>
									<th  class="col-sm-1"> Date </th>
						 
								<th  class="col-sm-1"> Dell/Edit </th>
						
							</tr>
						</thead>
						<tbody>
						<?php
						 
						 
							$result = mysqli_query($conn,"SELECT * FROM Announcements");
							while($row = mysqli_fetch_array($result))
								{
									
									echo '<td class="col-sm-0">'.$row['id'].'</td>';
									echo '<td class="col-sm-2">'.$row['Details'].'</td>';
									echo '<td class="col-sm-2">'.$row['Date'].'</td>';
				 
									
									
									echo '<td class="col-sm-5  text-center"><a class="btn btn-success" href="editAnnouncements.php?id='.$row['id'].'"><span class="glyphicon glyphicon-trash" aria-hidden="true"></span>Edit</a>|<a class="btn btn-danger" href="DelAnnouncements.php?id='.$row['id'].'"><span class="glyphicon glyphicon-ban-circle" aria-hidden="true"></span>Delete</a> </div></td>';
									echo '</tr>';
								} 
	
							?> 
						</tbody>
					</table>
    </div></div>
    
  </div>
 <!-- Dynamic content goes here -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

</body>
</html>