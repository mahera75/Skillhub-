<style>
.task{

background-color: #00CC33;
}

</style>



<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
    <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
        <a href=" "> <img src="images/logo.png" class="responsive" height="50px" style="margin-top:-5px"></a>
    </div>
    <!-- Top Menu Items -->
     
    <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
    <div class="collapse navbar-collapse navbar-ex1-collapse">
        <ul class="nav task  side-nav">
            
        <li><a href="index.php">Home</a></li>
           <li><a href="RegisterStudent.php">Register Student </a></li>
		      <li><a href="Userlogin.php">User Login</a></li>
           <li><a href="RegisterCourseCreator.php">RegisterCourseCreator </a></li>
            <li><a href="adminlogin.php">Admin Login</a></li>
			 <li><a href="HTTTP\\WWW.VU.EDU.PK">VU LMS</a></li>

        </ul>
    </div>
    <!-- /.navbar-collapse -->
</nav>