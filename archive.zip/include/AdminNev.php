
<style>
.task{

background-color:#FF9966;
}

</style>


<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
    <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
        <a href=" "> <img src="images/logo.png" class="responsive" height="50px" style="margin-top:-5px"></a>
    </div>
    <!-- Top Menu Items -->
     
    <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
    <div class="collapse navbar-collapse navbar-ex1-collapse">
        <ul class="nav navbar-nav side-nav">
            <li><a  > (Admin) </a></li>
        <li><a href="AdminHome.php"> Manage Users  </a></li>
  <li><a href="ViewResultAdmin.php"> View student Result   </a></li>
        <li><a href="logout.php">Logout</a></li>
  
        </ul>
    </div>
    <!-- /.navbar-collapse -->
</nav>