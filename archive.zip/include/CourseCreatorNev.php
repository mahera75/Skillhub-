
<style>
.task{

background-color: #00CC00;
}

</style>


<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
    <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
        <a href=" "> <img src="images/logo.png" class="responsive" height="50px" style="margin-top:-5px"></a>
    </div>
    <!-- Top Menu Items -->
     
    <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
    <div class="collapse navbar-collapse navbar-ex1-collapse">
        <ul class="nav tsak side-nav">
              <li><a > (Course Creator)) </a></li>
<li><a href="ManagePrograms.php"> ManagePrograms  </a></li>
	    <li><a href="DetailReport.php">	Manage Student Registration</a></li>
		   <li><a href="ManageResults.php">Manage Results</a></li>
			   <li><a href="ManageAnnouncements.php">Manage Announcements</a></li>
		 <li><a href="CourseMaterials.php">Course Materials</a></li>
		 <li><a href="MessageToStudent.php">Message To Student </a></li>
		  <li><a href="ViewStudentFee.php">View Student Fee </a></li>
		     <li><a href="EvaluateAssignment.php">Evaluate Assignments  </a></li>
		    <li><a href="Manageassignment.php">  Manage Assignment  </a></li>
        <li><a href="logout.php">Logout</a></li>

        </ul>
    </div>
    <!-- /.navbar-collapse -->
</nav>