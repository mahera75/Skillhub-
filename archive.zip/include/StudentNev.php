<style>
.task{

background-color:#FF9966;
}

</style>


<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
    <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
        <a href=" "> <img src="images/logo.png" class="responsive" height="50px" style="margin-top:-5px"></a>
    </div>
    <!-- Top Menu Items -->
     
    <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
    <div class="collapse navbar-collapse navbar-ex1-collapse">
        <ul class="nav navbar-nav side-nav">
            <li><a > (Student) </a></li>
<li><a href="StudentHome.php"> Manage Profile  </a></li>
<li><a href="ApplyToRegister.php">Apply to Register </a></li>				  
<li><a href="ViewRegisterationDetials.php">View Registeration Detials</a></li> 
<li><a href="ViewAnnouncements.php">View Announcements</a></li>
<li><a href="ViewResults.php">View Results</a></li>
<li><a href="MessageToCC.php">Message to Course Creator </a></li>
<li><a href="ManageStudentFee.php">Manage   Fee</a></li>
<li><a href="Viewassignment.php">View  Assignments</a></li>
<li><a href="ManageAssignmentSolution.php">Manage Assignment Solution</a></li>
<li><a href="logout.php">Logout</a></li>

        </ul>
    </div>
    <!-- /.navbar-collapse -->
</nav>