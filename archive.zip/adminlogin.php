<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>SkillHubOnlinePlatformForSelf-PacedShortCourses</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/sb-admin.css" rel="stylesheet">
    <link href="css/plugins/morris.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

</head>
<body>

    <div id="wrapper">

        <!-- Navigation -->
         <!-- The navigation will be inserted here -->

        <div id="page-wrapper">
            <div class="container-fluid">
                
<?php
 
include 'include/connection.php';
 

if(isset($_POST['login']))
{
	$email = $_POST['email'];
	$password =$_POST['password'];
	$res=mysqli_query($conn,"SELECT * FROM admin WHERE Email='$email' AND Password='$password'");
	$row=mysqli_fetch_array($res);
 
      if($row['Password']==$password)
	{
		$_SESSION['EmailAdm'] = $row['Email'];
		header("Location: AdminHome.php");
	}
	else
	?>
        <script>alert('Invalid Username  or Password!');</script>
		<?php
		
       
 
} 
?> 
    <?php include("include/GenNev.php"); ?>
     
  
  <div class="container">
    <div class="row">
      <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 hidden-xs">
        <div>
<form method="post"  >
  
  <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">&nbsp;&nbsp;Admin Log-in </h4>
         
        </div>
        <div class="modal-body">
               <div class="form-group">
                  <label for="usr">Email</label>
                   <div class="input-group">
				   
				   <input type="email" class="form-control" id="usr" name="email" placeholder="Enter Your Email" required />
               </div>
			   </div>
			   
			   
			   <div class="form-group">
                  <label for="pwd" >Password</label>
                  <div class="input-group">
				   
				   <input type="password" class="form-control" id="pwd" name="password" placeholder="Enter Your Password" required />
               </div>
			   </div>
			 
			 
			 
			 
			   
			   <div class="modal-footer">
          <div class="row"> 
              <div class="col-md-12 "> 
					<button id="singlebutton" name="login" class="btn btn-primary">Login</button>
					  
			       
		  		
		     </div>
		  
         </div>
      
              </div>
   
</form>
</div>
      </div>
    </div>
    
  </div> 

 <!-- Dynamic content goes here -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

</body>
</html>