<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>SkillHubOnlinePlatformForSelf-PacedShortCourses</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/sb-admin.css" rel="stylesheet">
    <link href="css/plugins/morris.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

</head>
<body>

    <div id="wrapper">

        <!-- Navigation -->
         <!-- The navigation will be inserted here -->

        <div id="page-wrapper">
            <div class="container-fluid">
                
 
<?php

include 'include/connection.php';
$Teacher=$_SESSION['EmailCC'];



if(isset($_POST['btn']))
{
    
	 
	$Subject = $_POST['Subject'];
	$LastDate =$_POST['LastDate'];
 
	 $QuestionsFile = rand(1000,100000)."-".$_FILES['QuestionsFile']['name']; 
    $file_loc = $_FILES['QuestionsFile']['tmp_name']; 		
 $folder="images/";
move_uploaded_file($file_loc,$folder.$QuestionsFile);
 
 
	if(mysqli_query($conn,"INSERT INTO assignments(QuestionsFile,Subject,LastDate,Teacher) VALUES('$QuestionsFile','$Subject','$LastDate','$Teacher')"))
	{
		?>
        <script>alert('successfully done ');</script>
        <?php
	}
	else
	{
		?>
        <script>alert('error while input data...');</script>
        <?php
	}
}
?>

    
    <?php include("include/CourseCreatorNev.php"); ?>
     
  
  <div class="container">
    <div class="row">
      <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 hidden-xs">
        <div>
		 <div class="panel panel-primary" >
      <div class="panel-heading text-center" ><h4>&nbsp;&nbsp;Manage assignments  Question Files</h4></div>
<div class="panel-body">
<!-- 5555555555-->
<form method="post"  enctype="multipart/form-data">
  
  <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">&nbsp;&nbsp;Input  Data For assignments </h4>
         
        </div>
		
		
        <div class="modal-body">
		
		<div class="form-group">
                  <label for="pwd" >Select Questions File</label>
                  <div class="input-group">
				   
				    <input  class="form-control"   type="file" name="QuestionsFile" placeholder="Enter Your product_name" required />
				   
               </div>
			   </div>
			   
               <div class="form-group">
                  <label for="usr">Subject</label>
                   <div class="input-group">
				    	   <table>
<tr>
<td>
   <div>
   
 
		<select class="form-control" id="Student" name="Subject"   required/><?php
		$ddl=mysqli_query($conn,"select * from Programs  ") ;
		  while($row=mysqli_fetch_array($ddl))
{ ?>
<option value="<?php print $row['ProgramsTitle']; ?>"><?php print $row['ProgramsTitle'];
?>
<?php
}?>

</table>
			
				   
				 
               </div>
			   </div>
			   
			   
			   <div class="form-group">
                  <label for="pwd" >LastDate</label>
                  <div class="input-group">
				   
				   <input type="date" class="form-control" id="LastDate" name="LastDate" placeholder="Enter LastDate" required />
               </div>
			   </div>
			 
			
			 
			 
			   
			   
		 
			 
			 
			
			 
			   
			   <div class="modal-footer">
          <div class="row"> 
              <div class="col-md-12 "> 
					<button id="btn" name="btn" class="btn btn-primary">Submit</button>
				
					 
			       		
		  		
		     </div>
		  
         </div>
      
              </div>
   
</form>
                    </div>
</div>
      </div>
	  <table class="table table-bordered table-responsive">
						<thead>
							<tr >
								
                                <th  class="col-sm-1"> ID </th>
								<th  class="col-sm-1"> QuestionsFile </th>
									<th  class="col-sm-1"> Subject </th>
									<th  class="col-sm-1"> LastDate </th>
									<th  class="col-sm-1"> Teacher </th>
			 
								<th  class="col-sm-1"> Dell/Edit </th>
						
							</tr>
						</thead>
						<tbody>
						<?php
					 
							 
							$result = mysqli_query($conn,"SELECT * FROM assignments where Teacher = '$Teacher'");
							while($row = mysqli_fetch_array($result))
								{
									
									echo '<td class="col-sm-0">'.$row['id'].'</td>';
									///file:///C:/wamp/www/Web-BasedAssignmentEvaluator/images/53431-Requirments%20.docx
									$encodedFileName = urlencode($row['QuestionsFile']);
echo '<td class="col-sm-2"><a href="images/' . $encodedFileName . '" download>Download</a></td>';

								//	echo '<td class="col-sm-2"><a href="/images/'.$row['QuestionsFile'].'" download>Download</a></td>';

									echo '<td class="col-sm-2">'.$row['Subject'].'</td>';
									echo '<td class="col-sm-2">'.$row['LastDate'].'</td>';
										echo '<td class="col-sm-2">'.$row['Teacher'].'</td>';
						 
									
									
									echo '<td class="col-sm-5  text-center"> <a class="btn btn-primary" href="Delassignments.php?id='.$row['id'].'">Delete</a> </div></td>';
									echo '</tr>';
								} 
	
							?> 
						</tbody>
					</table>
    </div></div>
    
  </div> <!-- Dynamic content goes here -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

</body>
</html>