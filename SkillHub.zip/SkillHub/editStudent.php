<!DOCTYPE html>
<html lang="en">
<head>
<?php


include 'include/connection.php';


	$id=$_GET['id'];
	$result = mysqli_query($conn, "SELECT * FROM StudentProfile where id='$id'");
		while($row = mysqli_fetch_array($result))
			{
			$FirstName = $row['FirstName'];
			$LastName = $row['LastName'];
			$Password = $row['Password'];
			$DateOfBirth= $row['DateOfBirth'];
			$Gender = $row['Gender'];
			$CellNumber = $row['CellNumber'];
			
			
			}
?>

<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>SkillHub</title>


<link rel="stylesheet" href="css/bootstrap.css">


</head>
<body>
<nav class="navbar navbar-inverse">
  <div class="container-fluid"> 
    
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#myInverseNavbar2" aria-expanded="false"> <span class="sr-only">Code66</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
       </div>
    
    <?php include("include/StudentNev.php"); ?>
     
  </div>
   
</nav>
  <div class="container">
    <div class="row">
      <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 hidden-xs">
        <div>
<form method="post" action="EditQueryStudent.php">
  <input type="hidden" name="prodid" value="<?php echo @$id=$_GET['id'] ?>">
  <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">&nbsp;&nbsp;Input Data to Update</h4>
         
        </div>
		
		
        <div class="modal-body">
		
		<div class="form-group">
                  <label for="pwd" >FirstName</label>
                  <div class="input-group">
				   
				   <input type="text" class="form-control" id="FirstName" name="FirstName" value="<?php echo $FirstName  ?>" required />
               </div>
			   </div>
			   
               <div class="form-group">
                  <label for="usr">LastName</label>
                   <div class="input-group">
				   
				   <input type="text" class="form-control" id="usr" name="LastName" value="<?php echo $LastName  ?>" required />
               </div>
			   </div>
			   
			   
			   <div class="form-group">
                  <label for="pwd" >Password</label>
                  <div class="input-group">
				   
				   <input type="text" class="form-control" id="Password" name="Password" value="<?php echo $Password  ?>" required />
               </div>
			   </div>
			 
			
			 
			 
			   
			   
			 
			 
			 <div class="form-group">
                  <label for="pwd" >DateOfBirth</label>
                  <div class="input-group">
				   
				   <input type="text" class="form-control" id="DateOfBirth" name="DateOfBirth" value="<?php echo $DateOfBirth?>" required />
               </div>
			   </div>
			 
			   
			   
			   
			   
			    <div class="form-group">
                  <label for="pwd" >Gender</label>
                  <div class="input-group">
				   
				   <input type="text" class="form-control" id="Gender" name="Gender" value="<?php echo $Gender  ?>" required />
               </div>
			   </div>
			 
			    <div class="form-group">
                  <label for="pwd" >CellNumber</label>
                  <div class="input-group">
				   
				   <input type="text" class="form-control" id="CellNumber" name="CellNumber" value="<?php echo $CellNumber  ?>" required />
               </div>
			   </div>
			 
			
			 
			
			 
			   
			   <div class="modal-footer">
          <div class="row"> 
              <div class="col-md-12 "> 
					<button id="btn" name="btn" class="btn btn-primary">Submit</button>
				
				
			       		
		  		
		     </div>
		  
         </div>
      
              </div>
   
</form>
</div>
      </div>
    </div>
    
  </div>









</body>
</html>