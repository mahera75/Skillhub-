<?php

include 'include/connection.php';

{
$id=$_GET['id'];
 $sql = "delete from StudentProfile where id='$id'";
 mysqli_query($conn, $sql);
}
	
	
	header("location: StudentHome.php");
?>