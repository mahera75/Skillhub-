
<?php
	
		include 'include/connection.php';
		
			$stdid = $_GET['stdid'];
	 $rand=rand(1,99999);
 
 
	
  			mysqli_query($conn, "UPDATE `appliedlist` SET `Status`='AdmissionRejected',`key`='$rand' WHERE `id`='$stdid'");
	
	header("location: DetailReport.php");
	
?>