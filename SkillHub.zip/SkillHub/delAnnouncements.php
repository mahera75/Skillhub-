<?php

include 'include/connection.php';

{
$id=$_GET['id'];
 $sql = "delete from Announcements where id='$id'";
 mysqli_query($conn, $sql);
}
	
	
	header("location: ManageAnnouncements.php");
?>