<?php

include 'include/connection.php';

{
$id=$_GET['id'];
 $sql = "delete from Programs where id='$id'";
 mysqli_query($conn, $sql);
}
	
	
	header("location: ManagePrograms.php");
?>