
<?php
	
		include 'include/connection.php';
		
			$prodid = $_POST['prodid'];
		$FirstName = $_POST['FirstName'];
			$LastName = $_POST['LastName'];
			$Password = $_POST['Password'];
			$DateOfBirth= $_POST['DateOfBirth'];
			$Gender = $_POST['Gender'];
			$CellNumber = $_POST['CellNumber'];
			
	
	
  			mysqli_query($conn, "UPDATE StudentProfile SET 			FirstName='$FirstName',LastName='$LastName',Password='$Password',DateOfBirth='$DateOfBirth',Gender='$Gender',CellNumber='$CellNumber' WHERE id='$prodid'");
	
	header("location: StudentHome.php");
	
?>