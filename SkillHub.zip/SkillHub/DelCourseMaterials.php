<?php

include 'include/connection.php';

{
$id=$_GET['id'];
 $sql = "delete from CourseMaterials where id='$id'";
 mysqli_query($conn, $sql);
}
	
	
	header("location: CourseMaterials.php");
?>