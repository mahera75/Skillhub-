<!DOCTYPE html>
<html lang="en">
<head>
<?php


include 'include/connection.php';


	$id=$_GET['id'];
	$result = mysqli_query($conn, "SELECT * FROM Announcements where id='$id'");
		while($row = mysqli_fetch_array($result))
			{
			$Details = $row['Details'];
 
			
			}
?>

<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>SkillHub</title>


<link rel="stylesheet" href="css/bootstrap.css">


</head>
<body>
<nav class="navbar navbar-inverse">
  <div class="container-fluid"> 
    
    <div class="navbar-header">
      
       </div>
    
    <?php include("include/CourseCreatorNev.php"); ?>
     
  </div>
   
</nav>
  <div class="container">
    <div class="row">
      <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 hidden-xs">
        <div>
<form method="post" action="EditQueryAnnouncements.php">
  <input type="hidden" name="prodid" value="<?php echo @$id=$_GET['id'] ?>">
  <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title"><span class="glyphicon glyphicon-log-in" aria-hidden="true"></span>&nbsp;&nbsp;Input Data to Update Announcements</h4>
         
        </div>
		
		
        <div class="modal-body">
		
		<div class="form-group">
                  <label for="pwd" >Details</label>
                  <textarea  class="form-control"  name="Details" cols="6" rows="3"><?php echo $Details  ?></textarea>
 
            
			   </div>
			   
       
			 
			
			 
			   
			   <div class="modal-footer">
          <div class="row"> 
              <div class="col-md-12 "> 
					<button id="btn" name="btn" class="btn btn-danger">Submit</button>
				
				
			       		
		  		
		     </div>
		  
         </div>
      
              </div>
   
</form>
</div>
      </div>
    </div>
    <hr>
  </div>

<hr>
<div class="container">
  <div class="row">
    <div class="col-lg-9 col-md-12">

<!--Place to put code 99999
      -->
    </div>
    
  </div>
</div>
<hr>

<hr>
<div class="container well">
  <div class="row">
<div class="col-xs-6 col-sm-6 col-lg-4 col-md-4"> <span class="text-right">
      </span>
  <h3>About Us</h3>
  <hr>
  <p></p>
</div>
<div class="col-xs-6 col-sm-6 col-lg-4 col-md-4 hidden-sm hidden-xs"> <span class="text-right"> </span>
  <h3>Latest News</h3>
  <hr>
  <div class="media-object-default">
  <div class="media">
  <div class="media-body">
        <h4 class="media-heading"></h4>
 </div>
      <div class="media-right"> <a href="#"> </a></div>
</div>
<div class="media">
  <div class="media-body">
    <h4 class="media-heading"></h4></div>
  <div class="media-right"> <a href="#"></a></div>
</div>
</div>
</div>
<div class="col-xs-6 col-sm-6 col-lg-4 col-md-4"> <span class="text-right"> </span>
  <h3>Contact Us</h3>
  <hr>

    

      
</div>
  </div>
</div>
<footer class="text-center">
  <div class="container">
    <div class="row">
      <div class="col-xs-12">
        <p>Virtual University of Pakistan.</p>
      </div>
    </div>
  </div>
</footer>
<script src="js/jquery-1.11.3.min.js"></script> 

<script src="js/bootstrap.js"></script>
</body>
</html>