<!DOCTYPE html>
<html lang="en">
<head>
 
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">


<title>EDUHUB </title>

<!-- Bootstrap -->
<link rel="stylesheet" href="css/bootstrap.css">


</head> 
<body>

   <nav class="navbar navbar-inverse">
  <div class="container-fluid"> 
    
    <div class="navbar-header">
      
       </div>
    
    <?php include("include/StudentNev.php"); ?>
    <!-- /.navbar-collapse --> 
  </div>
  <!-- /.container-fluid --> 
</nav>
   
   
<?php

 
include 'include/connection.php';

if(isset($_POST['btn']))
{
    
	$msg = $_POST['msg'];
	
		$UserID= $_POST['UserID'];
	
 
	if(mysqli_query($conn,"INSERT INTO `Messages`(`message`, `sender`, `reciver`) VALUES ('$msg','$user','$UserID')"))
	{
		?>
        <script>alert('successfully done ');</script>
        <?php
	}
	else
	{
		?>
        <script>alert('error while input data...');</script>
        <?php
	}
}
?>





    

  <div class="container">
    <div class="row">
      <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 hidden-xs">
        <div>
		 <div class="panel panel-primary" >
		 
      <div class="panel-heading text-center" ><h4>&nbsp;&nbsp;Message to Course Creator </h4></div>
<div class="panel-body">
<div class="panel-body">
<form method="post" >
  
  <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">&nbsp;&nbsp;Input Data to Send Messages</h4>
         
        </div>
		
		
        <div class="modal-body">
		
			
		
		<div class="form-group">
                  <label for="pwd" >Message</label>
                
				   
				   <textarea class="form-control"   name="msg"  cols="4" rows="3"></textarea>
		 
			   </div>
			   
        
			 
			<div class="form-group">
                  <label for="pwd" >Message To : </label>
                  <div class="input-group">
				   
				   

 
				  
<table>
<tr>
<td>
   <div>
   <?php
	 
$list=mysqli_query($conn,"SELECT * FROM `studentprofile` where UserType='CourseCreator'");
?>
 
		<select name="UserID" class="form-control" required/><?php

  while($row=mysqli_fetch_array($list))
{ ?>
<option value="<?php print $row['Email']; ?>"><?php print $row['Email'];
?>
<?php
}?> </option></select>

</table>

			 
               </div>
			   </div>
			 
			   
			   <div class="modal-footer">
          <div class="row"> 
              <div class="col-md-12 "> 
					<button id="btn" name="btn" class="btn btn-danger">Submit</button>
				
					 
			       		
		  		
		     </div>
		  
         </div>
      
              </div>
   
</form>
 
                    </div>
 <table class="table table-bordered table-responsive">
						<thead>
							<tr >
								
                                <th  class="col-sm-1">Reciver </th>
								<th  class="col-sm-1"> Message </th>
									<th  class="col-sm-1"> Sender ID</th>
								
						
							</tr>
						</thead>
						<tbody>
						<?php
						 
							
 
							$result = mysqli_query($conn,"SELECT * FROM Messages where sender='$user' OR reciver='$user'");
							while($row = mysqli_fetch_array($result))
								{
									
									
								echo '<td class="col-sm-2">'.$row['reciver'].'</td>';
									echo '<td class="col-sm-2">'.$row['message'].'</td>';
									echo '<td class="col-sm-2">'.$row['sender'].'</td>';

							
									
			
									echo '</tr>';
								} 
	
							?> 
						</tbody>
					</table>
                    </div>
</div>
      </div>
    </div></div>
    
  </div>








 
 
 



</body>
</html>