
<?php

include 'include/connection.php';
 
		
			$id = $_GET['id'];
	 
 
 
	
  			mysqli_query($conn, "UPDATE `studentprofile` SET  `status`='Approved' WHERE `id` ='$id'");
	
	header("location: AdminHome.php");
	
?>