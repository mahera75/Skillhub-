<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">


<title>SkillHub</title>


<link rel="stylesheet" href="css/bootstrap.css">


</head>
<body>
<nav class="navbar navbar-inverse">
  <div class="container-fluid"> 
    
    <div class="navbar-header">
      
       </div>
    
    <?php include("include/AdminNev.php"); ?>
     
  </div>
   
</nav>
  <div class="container">
    <div class="row">
      <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 hidden-xs">
        <div>
		<div class="panel panel-primary" >
		<div class="panel-heading text-center" ><h4>&nbsp;&nbsp;Manage Users</h4></div>
<div class="panel-body">
 <table class="table table-bordered table-responsive">
						<thead>
							<tr  >
								
                                <th  class="col-sm-1"> ID </th>
								<th  class="col-sm-1"> FirstName </th>
									<th  class="col-sm-1"> Email </th>
									<th  class="col-sm-1"> LastName	 </th>
									<th  class="col-sm-1"> DateOfBirth </th>
									<th  class="col-sm-1"> CellNumber </th>
											<th  class="col-sm-1">  User Type</th>
								 <th  class="col-sm-1"> Status </th>
								 
								<th  class="col-sm-1"> Action </th>
						<th  class="col-sm-1"> Action </th>
							</tr>
						</thead>
						<tbody class="row">
						<?php
						 
							include 'include/connection.php';
							$result = mysqli_query($conn,"SELECT * FROM studentprofile");
							while($row = mysqli_fetch_array($result))
								{
									
									echo '<td class="col-sm-0">'.$row['id'].'</td>';
									echo '<td class="col-sm-2">'.$row['FirstName'].'</td>';
									echo '<td class="col-sm-2">'.$row['Email'].'</td>';
									echo '<td class="col-sm-2">'.$row['LastName'].'</td>';
										echo '<td class="col-sm-2">'.$row['DateOfBirth'].'</td>';
									echo '<td class="col-sm-2">'.$row['CellNumber'].'</td>';
									 			echo '<td class="col-sm-2">'.$row['UserType'].'</td>';
			echo '<td class="col-sm-2">'.$row['status'].'</td>';
									
									echo '<td class="col-sm-5  text-center"><a class="btn btn-primary" href="Del.php?id='.$row['id'].'">Delete</a> </div></td>';
										echo '<td class="col-sm-5  text-center"><a class="btn btn-primary" href="Approve.php?id='.$row['id'].'">Approve</a> </div></td>';
									echo '</tr>';
								} 
	
							?> 
						</tbody>
					</table>
                    </div>
</div>
      </div>
    </div></div>
    
  </div>








 

</body>
</html>