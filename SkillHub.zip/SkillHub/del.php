<?php

include 'include/connection.php';

{
$id=$_GET['id'];
 $sql = "delete from studentprofile where id='$id'";
 mysqli_query($conn, $sql);
}
	
	
	header("location: AdminHome.php");
?>