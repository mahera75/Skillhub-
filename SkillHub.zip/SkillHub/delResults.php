<?php

include 'include/connection.php';

{
$id=$_GET['id'];
 $sql = "delete from Results where id='$id'";
 mysqli_query($conn, $sql);
}
	
	
	header("location: ManageResults.php");
?>