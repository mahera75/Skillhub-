<!DOCTYPE html>
<html lang="en">
<head>
<?php


include 'include/connection.php';
 
?>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">


<title>SkillHub</title>


<link rel="stylesheet" href="css/bootstrap.css">


</head>
<body>
<nav class="navbar navbar-inverse">
  <div class="container-fluid"> 
    
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#myInverseNavbar2" aria-expanded="false"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
       </div>
    
    <?php include("include/StudentNev.php"); ?>
     
  </div>
   
</nav>
  <div class="container">
    <div class="row">
      <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 hidden-xs">
        <div>
		 <div class="panel panel-primary" >
      <div class="panel-heading text-center" ><h4>&nbsp;&nbsp;Manage CourseMaterials  LIST</h4></div>
<div class="panel-body">
<!-- 5555555555-->

                    </div>
</div>
      </div>
	  <table class="table table-bordered table-responsive">
						<thead>
							<tr  >
								
                                
								<th  class="col-sm-1"> Course </th>
									<th  class="col-sm-1"> file </th>
	 <th  class="col-sm-1"> Action </th>
								 
						
							</tr>
						</thead>
						<tbody class="row">
						<?php
				 
						 $Course=$_GET['Course'];
							$result = mysqli_query($conn,"SELECT * FROM CourseMaterials where Course='$Course'");
							while($row = mysqli_fetch_array($result))
								{
									
									echo '<td class="col-sm-0">'.$row['id'].'</td>';
									echo '<td class="col-sm-2">'.$row['Course'].'</td>';
								 
echo '<td class="col-sm-2"><a href="images/' . $row['file'] . '" download>Download</a></td>';
  
									echo '</tr>';
								} 
	
							?> 
						</tbody>
					</table>
    </div></div>
    
  </div>









</body>
</html>