
<?php
	
		include 'include/connection.php';
		
			$prodid = $_POST['prodid'];
		$ProgramsTitle = $_POST['ProgramsTitle'];
			$EligibilityCriteria = $_POST['EligibilityCriteria'];
			$Type = $_POST['Type'];
			$Duration = $_POST['Duration'];
			$Fee = $_POST['Fee'];
			$PreRequisite = $_POST['PreRequisite'];
			
 
	
  			mysqli_query($conn, "UPDATE Programs SET 			ProgramsTitle='$ProgramsTitle',EligibilityCriteria='$EligibilityCriteria',Type='$Type',Duration='$Duration',Fee='$Fee',PreRequisite='$PreRequisite' WHERE id='$prodid'");
	
	header("location: ManagePrograms.php");
	
?>