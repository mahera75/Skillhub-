<?php

include 'include/connection.php';

{
$id=$_GET['id'];
 $sql = "delete from StudentFee where id='$id'";
 mysqli_query($conn, $sql);
}
	
	
	header("location: ManageStudentFee.php");
?>