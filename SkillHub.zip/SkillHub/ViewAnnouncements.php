<!DOCTYPE html>
<html lang="en">
<head>
<?php


include 'include/connection.php';
 
?>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">


<title>SkillHub</title>


<link rel="stylesheet" href="css/bootstrap.css">


</head>
<body>
<nav class="navbar navbar-inverse">
  <div class="container-fluid"> 
    
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#myInverseNavbar2" aria-expanded="false"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
       </div>
    
    <?php include("include/StudentNev.php"); ?>
     
  </div>
   
</nav>
  <div class="container">
    <div class="row">
      <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 hidden-xs">
        <div>
		 <div class="panel panel-danger" >
      <div class="panel-heading text-center" ><h4><span class="glyphicon glyphicon-th-list" aria-hidden="true"></span>&nbsp;&nbsp;View Announcements  LIST</h4></div>
 
</div>
      </div>
	  <table class="table table-bordered table-responsive">
						<thead>
							<tr >
								
                                	<th  class="col-sm-1"> ID </th>
								<th  class="col-sm-1"> Details </th>
									<th  class="col-sm-1"> Date </th>
						 
						 
						
							</tr>
						</thead>
						<tbody class="row">
						<?php
						 
						 
							$result = mysqli_query($conn,"SELECT * FROM Announcements");
							while($row = mysqli_fetch_array($result))
								{
									
									echo '<td class="col-sm-0">'.$row['id'].'</td>';
									echo '<td class="col-sm-2">'.$row['Details'].'</td>';
									echo '<td class="col-sm-2">'.$row['Date'].'</td>';
				 
									
									
							 
									echo '</tr>';
								} 
	
							?> 
						</tbody>
					</table>
    </div></div>
    <hr>
  </div>

<hr>
<div class="container">
  <div class="row">
    <div class="col-lg-9 col-md-12">

<!--Place to put code 99999
      -->
    </div>
    
  </div>
</div>
<hr>

<hr>
<div class="container well">
  <div class="row">
<div class="col-xs-6 col-sm-6 col-lg-4 col-md-4"> <span class="text-right">
      </span>
  <h3>About Us</h3>
  <hr>
  <p></p>
</div>
<div class="col-xs-6 col-sm-6 col-lg-4 col-md-4 hidden-sm hidden-xs"> <span class="text-right"> </span>
  <h3>Latest News</h3>
  <hr>
  <div class="media-object-default">
  <div class="media">
  <div class="media-body">
        <h4 class="media-heading"></h4>
 </div>
      <div class="media-right"> <a href="#"> </a></div>
</div>
<div class="media">
  <div class="media-body">
    <h4 class="media-heading"></h4></div>
  <div class="media-right"> <a href="#"></a></div>
</div>
</div>
</div>
<div class="col-xs-6 col-sm-6 col-lg-4 col-md-4"> <span class="text-right"> </span>
  <h3>Contact Us</h3>
  <hr>

    

      
</div>
  </div>
</div>
<footer class="text-center">
  <div class="container">
    <div class="row">
      <div class="col-xs-12">
        <p>Virtual University of Pakistan.</p>
      </div>
    </div>
  </div>
</footer>
<script src="js/jquery-1.11.3.min.js"></script> 

<script src="js/bootstrap.js"></script>
</body>
</html>