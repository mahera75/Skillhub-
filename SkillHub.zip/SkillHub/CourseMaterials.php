<!DOCTYPE html>
<html lang="en">
<head>
<?php


include 'include/connection.php';

if(isset($_POST['btn']))
{
    
	$Course = $_POST['Course'];
	
	 
 
  $file = rand(1000,100000)."-".$_FILES['file']['name']; 
    $file_loc = $_FILES['file']['tmp_name']; 		
 $folder="images/";
move_uploaded_file($file_loc,$folder.$file);
 
 
 
 
	if(mysqli_query($conn,"INSERT INTO CourseMaterials(Course,file,ccemail ) VALUES('$Course','$file','$cc' )"))
	{
		?>
        <script>alert('successfully done ');</script>
        <?php
	}
	else
	{
		?>
        <script>alert('error while input data...');</script>
        <?php
	}
}
?>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">


<title>SkillHub</title>


<link rel="stylesheet" href="css/bootstrap.css">


</head>
<body>
<nav class="navbar navbar-inverse">
  <div class="container-fluid"> 
    
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#myInverseNavbar2" aria-expanded="false"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
       </div>
    
    <?php include("include/CourseCreatorNev.php"); ?>
     
  </div>
   
</nav>
  <div class="container">
    <div class="row">
      <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 hidden-xs">
        <div>
		 <div class="panel panel-primary" >
      <div class="panel-heading text-center" ><h4>&nbsp;&nbsp;Manage CourseMaterials  LIST</h4></div>
<div class="panel-body">
<!-- 5555555555-->
<form method="post"  enctype="multipart/form-data">
  
  <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">&nbsp;&nbsp;Input Data For CourseMaterials </h4>
         
        </div>
		
		
        <div class="modal-body">
		
		<div class="form-group">
                  <label for="pwd" >Course</label>
                  <div class="input-group">
				   
				   	   <table>
<tr>
<td>
   <div>
   
 
		<select class="form-control"  name="Course" required/><?php
		$ddl=mysqli_query($conn,"select * from programs   ") ;
		  while($row=mysqli_fetch_array($ddl))
{ ?>
<option value="<?php print $row['ProgramsTitle']; ?>"><?php print $row['ProgramsTitle'];
?>
<?php
}?>

</table>
				   
               </div>
			   </div>
			   
               <div class="form-group">
                  <label for="usr">file</label>
                   <div class="input-group">
				   
				   <input  class="form-control"   type="file" name="file" placeholder="Enter Your product_name" required />
				   
               </div>
			   </div>
			   
			   
			  
			 
			
			 
			   
			   <div class="modal-footer">
          <div class="row"> 
              <div class="col-md-12 "> 
					<button id="btn" name="btn" class="btn btn-primary">Submit</button>
				
					 <button type="reset" class="btn btn-primary" value="Reset">Reset</button>
			       		
		  		
		     </div>
		  
         </div>
      
              </div>
   
</form>
                    </div>
</div>
      </div>
	  <table class="table table-bordered table-responsive">
						<thead>
							<tr  >
								
                                
								<th  class="col-sm-1"> Course </th>
									<th  class="col-sm-1"> file </th>
	 <th  class="col-sm-1"> Action </th>
								<th  class="col-sm-1"> Dell/Edit </th>
						
							</tr>
						</thead>
						<tbody class="row">
						<?php
				 
						 
							$result = mysqli_query($conn,"SELECT * FROM CourseMaterials where ccemail='$cc'");
							while($row = mysqli_fetch_array($result))
								{
									
									echo '<td class="col-sm-0">'.$row['id'].'</td>';
									echo '<td class="col-sm-2">'.$row['Course'].'</td>';
								 
echo '<td class="col-sm-2"><a href="images/' . $row['file'] . '" download>Download</a></td>';
 
									
									
									echo '<td class="col-sm-5  text-center"> <a class="btn btn-primary" href="DelCourseMaterials.php?id='.$row['id'].'"> Delete</a> </div></td>';
									echo '</tr>';
								} 
	
							?> 
						</tbody>
					</table>
    </div></div>
    
  </div>









</body>
</html>