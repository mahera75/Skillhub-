<?php
 session_start();
 @$user=$_SESSION['EmailStd'];
 @$adm=$_SESSION['EmailAdm'];
 @$cc=$_SESSION['EmailCC'];
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "SkillHub";
 

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

	?>