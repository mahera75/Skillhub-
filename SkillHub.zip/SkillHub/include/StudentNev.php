<div class="container-fluid"> 
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
       
      <a class="navbar-brand" href="#">EDUHUB</a> </div>
	  <div class="navbar-header bg-danger">
       
      <a class="navbar-brand" href="#"> (Student) </a>   </div>
    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="myInverseNavbar2">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="StudentHome.php"> Manage Profile  </a></li>
 
	<li><a href="ApplyToRegister.php">Apply to Register </a></li>
 
					  
 <li><a href="ViewRegisterationDetials.php">View Registeration Detials</a></li> 
		 	 <li><a href="ViewAnnouncements.php">View Announcements</a></li>
		  <li><a href="ViewResults.php">View Results</a></li>
		  <li><a href="MessageToCC.php">Message to Course Creator </a></li>
		    <li><a href="ManageStudentFee.php">Manage   Fee</a></li>
        <li><a href="logout.php">Logout</a></li>
        
      </ul>
    </div>
    <!-- /.navbar-collapse --> 
  </div>