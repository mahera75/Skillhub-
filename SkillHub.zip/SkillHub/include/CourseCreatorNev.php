<div class="container-fluid"> 
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
       
      <a class="navbar-brand" href="#">EDUHUB </a>   </div>
	  <div class="navbar-header bg-danger">
       
      <a class="navbar-brand" href="#"> (Course Creator) </a>   </div>
    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="myInverseNavbar2">
      <ul class="nav navbar-nav navbar-right">
  
		        <li><a href="ManagePrograms.php"> ManagePrograms  </a></li>
 
	    <li><a href="DetailReport.php">	Manage Student Registration</a></li>
		   <li><a href="ManageResults.php">Manage Results</a></li>
			   <li><a href="ManageAnnouncements.php">Manage Announcements</a></li>
		 <li><a href="CourseMaterials.php">Course Materials</a></li>
		 <li><a href="MessageToStudent.php">Message To Student </a></li>
		  <li><a href="ViewStudentFee.php">View Student Fee </a></li>
        <li><a href="logout.php">Logout</a></li>
        
      </ul>
	 
    </div>
    <!-- /.navbar-collapse --> 
  </div>