<div class="container-fluid"> 
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
       
      <a class="navbar-brand" href="#">EDUHUB</a> </div>
	  <div class="navbar-header bg-danger">
       
      <a class="navbar-brand" href="#"> (Admin) </a>   </div>
    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="myInverseNavbar2">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="AdminHome.php"> Manage Users  </a></li>
  <li><a href="ViewResultAdmin.php"> View student Result   </a></li>
        <li><a href="logout.php">Logout</a></li>
        
      </ul>
    </div>
    <!-- /.navbar-collapse --> 
  </div>