<div class="container-fluid"> 
    
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#myInverseNavbar2" aria-expanded="false"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
      <a class="navbar-brand" href="#">EDUHUB</a> </div>
    
    <div class="collapse navbar-collapse" id="myInverseNavbar2">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="index.php">Home</a></li>
           <li><a href="RegisterStudent.php">Register Student </a></li>
		      <li><a href="Userlogin.php">User Login</a></li>
           <li><a href="RegisterCourseCreator.php">RegisterCourseCreator </a></li>
            <li><a href="adminlogin.php">Admin Login</a></li>
        
        </li>
      </ul>
    </div>
    <!-- /.navbar-collapse --> 
  </div>