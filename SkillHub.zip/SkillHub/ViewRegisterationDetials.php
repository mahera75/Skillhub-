<!DOCTYPE html>
<html lang="en">
<head>
<?php


include 'include/connection.php';

if(isset($_POST['btn']))
{
    
	$ProgramsTitle = $_POST['ProgramsTitle'];
	
	 
	$Type =$_POST['Type'];
	$Duration =$_POST['Duration'];
 	$Fee =$_POST['Fee'];
 
 $ccemail =$_POST['ccemail'];
 $key =$ProgramsTitle.$user;
	if(mysqli_query($conn,"INSERT INTO `appliedlist`( `ProgramsTitle`, `StudentEmail`, `Type`, `Duration`, `Fee`, `ccemail`, `key`) VALUES ('$ProgramsTitle','$user','$Type','$Duration','$Fee','$ccemail' ,'$key' )"))
	{
		?>
        <script>alert('successfully done ');</script>
        <?php
	}
	else
	{
		?>
        <script>alert('You have already applied for that course  ...');</script>
        <?php
	}
}
?>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">


<title>SkillHub</title>


<link rel="stylesheet" href="css/bootstrap.css">


</head>
<body>
<nav class="navbar navbar-inverse">
  <div class="container-fluid"> 
    
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#myInverseNavbar2" aria-expanded="false"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
       </div>
    
    <?php include("include/StudentNev.php"); ?>
     
  </div>
   
</nav>
  <div class="container">
    <div class="row">
      <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 hidden-xs">
        <div>
		 <div class="panel panel-primary" >
      <div class="panel-heading text-center" ><h4>&nbsp;&nbsp;Manage Programs  LIST</h4></div>
<div class="panel-body">
<!-- 5555555555-->
 
                    </div>
</div>
      </div>
	  <table class="table table-bordered table-responsive">
						<thead>
							<tr  >
								
                                	<th  class="col-sm-1">ID </th>
								<th  class="col-sm-1"> ProgramsTitle </th>
									<th  class="col-sm-1"> StudentEmail </th>
									<th  class="col-sm-1"> Type </th>
									<th  class="col-sm-1"> Duration </th>
									<th  class="col-sm-1"> Fee </th>
									<th  class="col-sm-1"> Status </th>
						 
							 <th  class="col-sm-1"> Action </th>
						
							</tr>
						</thead>
						<tbody class="row">
						<?php
					  
							$result = mysqli_query($conn,"SELECT * FROM AppliedList where StudentEmail='$user'");
							while($row = mysqli_fetch_array($result))
								{
									
									echo '<td class="col-sm-0">'.$row['id'].'</td>';
									echo '<td class="col-sm-2">'.$row['ProgramsTitle'].'</td>';
									echo '<td class="col-sm-2">'.$row['StudentEmail'].'</td>';
									echo '<td class="col-sm-2">'.$row['Type'].'</td>';
										echo '<td class="col-sm-2">'.$row['Duration'].'</td>';
										echo '<td class="col-sm-2">'.$row['Fee'].'</td>';
										echo '<td class="col-sm-2">'.$row['Status'].'</td>';
					 if($row['Status']=='AdmissionApproved')
									{
								 echo '<td class="col-sm-5  text-center"><a class="btn btn-primary" href="ViewCourseContent.php?Course='.$row['ProgramsTitle'].'"> View Course Content</a> </div></td>'; }
								 
								 else { echo '<td class="col-sm-2">You can view after approvial</td>'; }
									echo '</tr>';
								} 
	
							?> 
						</tbody>
					</table>
    </div></div>
    
  </div>









</body>
</html>