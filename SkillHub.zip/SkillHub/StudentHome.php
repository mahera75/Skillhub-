<!DOCTYPE html>
<html lang="en">
<head>
<?php


include 'include/connection.php';


?>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">


<title>SkillHub</title>


<link rel="stylesheet" href="css/bootstrap.css">


</head>
<body>
<nav class="navbar navbar-inverse">
  <div class="container-fluid"> 
    
    <div class="navbar-header">
      
       </div>
    
    <?php include("include/StudentNev.php"); ?>
     
  </div>
   
</nav>
  <div class="container">
    <div class="row">
      <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 hidden-xs">
        <div>
		 <div class="panel panel-primary" >
      <div class="panel-heading text-center" ><h4>&nbsp;&nbsp;Manage Yoro Profile Informaiton</h4></div>
<div class="panel-body">
<!-- 5555555555-->

                    </div>
</div>
      </div>
	  <table class="table table-bordered table-responsive">
						<thead>
							<tr class = "row">
								
                                
								<th  class="col-sm-1"> FirstName </th>
									<th  class="col-sm-1"> LastName </th>
									<th  class="col-sm-1"> Password </th>
									<th  class="col-sm-1"> DateOfBirth</th>
									<th  class="col-sm-1"> Gender </th>
									<th  class="col-sm-1"> CellNumber </th>
									<th  class="col-sm-1"> Email </th>
								<th  class="col-sm-1"> Action </th>
						
							</tr>
						</thead>
						<tbody class="row">
						<?php
						
							$result = mysqli_query($conn,"SELECT * FROM StudentProfile where Email='$user'");
							while($row = mysqli_fetch_array($result))
								{
									
									echo '<td class="col-sm-0">'.$row['id'].'</td>';
									echo '<td class="col-sm-2">'.$row['FirstName'].'</td>';
									echo '<td class="col-sm-2">'.$row['LastName'].'</td>';
									echo '<td class="col-sm-2">'.$row['Password'].'</td>';
										echo '<td class="col-sm-2">'.$row['DateOfBirth'].'</td>';
										echo '<td class="col-sm-2">'.$row['Gender'].'</td>';
										echo '<td class="col-sm-2">'.$row['CellNumber'].'</td>';
										echo '<td class="col-sm-2">'.$row['Email'].'</td>';
									
									
									echo '<td class="col-sm-5  text-center"><a class="btn btn-primary" href="editStudent.php?id='.$row['id'].'">Edit</a>|<a class="btn btn-primary" href="DelStudent.php?id='.$row['id'].'">Delete Profile</a> </div></td>';
									echo '</tr>';
								} 
	
							?> 
						</tbody>
					</table>
    </div></div>
    
  </div>









</body>
</html>