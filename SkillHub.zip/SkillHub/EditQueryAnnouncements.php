
<?php
	
		include 'include/connection.php';
		
			$prodid = $_POST['prodid'];
		$Details = $_POST['Details'];
 
	
  			mysqli_query($conn, "UPDATE Announcements SET  Details='$Details'  WHERE id='$prodid'");
	
	header("location: ManageAnnouncements.php");
	
?>