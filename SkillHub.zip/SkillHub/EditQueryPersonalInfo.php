
<?php
	
		include 'include/connection.php';
		
			$prodid = $_POST['prodid'];
		$DreamsAndGoals = $_POST['DreamsAndGoals'];
			$InterestsAndValues = $_POST['InterestsAndValues'];
			$Skills = $_POST['Skills'];
			$Experience = $_POST['Experience'];
			$ExtraCurricular = $_POST['ExtraCurricular'];
		
	
  			mysqli_query($conn, "UPDATE PersonalInfo SET 			DreamsAndGoals='$DreamsAndGoals',InterestsAndValues='$InterestsAndValues',Skills='$Skills',Experience='$Experience',ExtraCurricular='$ExtraCurricular' WHERE id='$prodid'");
	
	header("location: ManagePersonalInfo.php");
	
?>