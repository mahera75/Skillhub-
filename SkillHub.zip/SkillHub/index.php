<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/bootstrap.css">

<title>SkillHub</title>

<link href="https://netdna.bootstrapcdn.com/bootstrap/3.0.0-rc2/css/bootstrap-glyphicons.css" rel="stylesheet">
<link rel="stylesheet" href="css/bootstrap.css">


</head>
<body>


<nav class="navbar navbar-inverse">
  <div class="container-fluid"> 
    
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#myInverseNavbar2" aria-expanded="false"> <span class="sr-only"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
       </div>
    
    <?php include("include/GenNev.php"); ?>
    </div>
   
</nav>
  
  


 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link href="http://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
  <link href="http://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
  <script src="js/jquery.min.js" ></script>
  
  <script src="js/bootstrap.min.js"></script>
<style>

.Sliderimg {
    opacity: 0.6;
    filter: alpha(opacity=50); /* For IE8 and earlier */
}
div.transbox {
  
  background-color: #ffffff;
  border: 1px solid black;
  opacity: 0.6;
  filter: alpha(opacity=60); /* For IE8 and earlier */
}

.ptb {
 /* margin: 5%;*/
  font-weight: bold;
  color: #000000;
}
.carousel-inner img {
      width: 100%; /* Set width to 100% */
      margin: auto;
      min-height:200px;
  }


</style>
 

<div id="carousel-example" class="carousel slide" data-ride="carousel">
 
  <div class="carousel-inner">
 
    <div class="item active">
      <a href="#"><img class=" img1" src="../EDUHUB/images/s1.png" height="1600" width="600" /></a>
     <div class="carousel-caption" >
                    
                    
                    <h1>EDUHUB</h1>
                    <p></p>
                </div>
    </div>
    <div class="item">
      <a href="#"><img class=" img1" src="../EDUHUB/images/s2.png" height="1600" width="600"/></a>
       <div class="carousel-caption">
                    <h1>EDUHUB</h1>
                    
                    <p></p>
                </div>
    </div>
    <div class="item">
      <a href="#"><img class=" img1" src="../EDUHUB/images/s3.png" height="1600" width="600"/></a>
       <div class="carousel-caption">
                    <h1>EDUHUB</h1>
                    
                    <p></p>
                </div>
    </div>
  </div>
  

  <a class="left carousel-control" href="#carousel-example" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left"></span>
  </a>
  <a class="right carousel-control" href="#carousel-example" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right"></span>
  </a>
</div>




<!-- Modal -->




</div>

<div class="container">

</div>

<!-- Footer -->
<footer class="container-fluid " style="background-color:black; color: white; ">


<div class="col-md-1"> <br></div>


</footer>

</body>
</html>
