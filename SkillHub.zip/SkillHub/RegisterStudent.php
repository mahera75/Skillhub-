<!DOCTYPE html>
<html lang="en">
<head>
<?php

include 'include/connection.php';



	 
 
	?>
<?php




 



if(isset($_POST['btn']))
{
    	 
	$FirstName = $_POST['FirstName'];
	
	$LastName = $_POST['LastName'];
	$Password =$_POST['Password'];
	$DateOfBirth=$_POST['DateOfBirth'];
 
 $Gender =$_POST['Gender'];
 $CellNumber =$_POST['CellNumber'];
 $Email =$_POST['Email'];
 
 
 	 
 
 
	if(mysqli_query($conn,"INSERT INTO StudentProfile(FirstName,LastName,Password,DateOfBirth,Gender,CellNumber,Email) VALUES('$FirstName','$LastName','$Password','$DateOfBirth','$Gender','$CellNumber','$Email')"))
	{
		?>
        <script>alert('successfully done  but you can login after admin approvial ');</script>
        <?php
	}
	else
	{
		?>
        <script>alert('error while register you because that email ID is already taken...');</script>
        <?php
	}  
	 
}
?>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">


<title>SkillHub</title>


<link rel="stylesheet" href="css/bootstrap.css">


</head>
<body>
<nav class="navbar navbar-inverse">
  <div class="container-fluid"> 
    
    <div class="navbar-header">
      
       </div>
    
    <?php include("include/GenNev.php"); ?>
     
  </div>
   
</nav>
  <div class="container">
    <div class="row">
      <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 hidden-xs">
        <div>
		 <div class="panel panel-primary" >
      <div class="panel-heading text-center" ><h4>&nbsp;&nbsp;Register with Us</h4></div>
<div class="panel-body">
<!-- 5555555555-->
<form method="post" >
  
  <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">&nbsp;&nbsp;Input Your Informaiton</h4>
         
        </div>
		
		
        <div class="modal-body">
		
		<div class="form-group">
                  <label for="pwd" >FirstName</label>
                  <div class="input-group">
				   
				   <input type="text" required  class="form-control" id="FirstName" name="FirstName" placeholder="Enter FirstName"  />
               </div>
			   </div>
			   
               <div class="form-group">
                  <label for="usr">Last Name</label>
                   <div class="input-group">
				   
				   <input type="text" required  class="form-control" id="usr" name="LastName" placeholder="Enter Last Name"  />
               </div>
			   </div>
			   
			   
			   <div class="form-group">
                  <label for="pwd" >Password</label>
                  <div class="input-group">
				   
				   <input type="password" required  class="form-control" id="Password" name="Password" placeholder="Enter Password"  />
               </div>
			   </div>
			   
			 
			 
			 <div class="form-group">
                  <label for="pwd" >Date Of Birth</label>
                  <div class="input-group">
				   
				   <input type="date" required  class="form-control" id="DateOfBirth" name="DateOfBirth" placeholder="Enter  Date Of Birth"  />
               </div>
			   </div>
			 
			   
			   
			   
			   
			    <div class="form-group">
                  <label for="pwd" >Gender</label>
                  <div class="input-group">
				   
				   <select class="form-control" id="Gender" name="Gender">
  <option value="Femail">Female</option>
  <option value="Male">Male</option>
 
</select>
				  
               </div>
			   </div>
			 
			    <div class="form-group">
                  <label for="pwd" >Cell Number</label>
                  <div class="input-group">
				   
				   <input type="number" required  class="form-control" id="CellNumber" name="CellNumber" placeholder="Enter CellNumber"  />
               </div>
			   </div>
			 
			  <div class="form-group">
                  <label for="pwd" >Email</label>
                  <div class="input-group">
				   
				   <input type="email" required  class="form-control"   name="Email" placeholder="Enter Email"  />
               </div>
			   </div>
			 
			 
			 
		 
			 
			   
			   <div class="modal-footer">
          <div class="row"> 
              <div class="col-md-12 "> 
					<button id="btn" name="btn" class="btn btn-primary">Submit</button>
				
					 <button type="reset" class="btn btn-primary" value="Reset">Reset</button>
			       		
		  		
		     </div>
		  
         </div>
      
              </div>
   
</form>
                    </div>
</div>
      </div>
	  
    </div></div>
    
  </div>









</body>
</html>