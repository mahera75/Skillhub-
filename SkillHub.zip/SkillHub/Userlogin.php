<!DOCTYPE html>
<html lang="en">
<head>
<?php
 
include 'include/connection.php';
 
 
 
if(isset($_POST['login']))
{
	$email = $_POST['email'];
	$password =$_POST['password'];
	$res=mysqli_query($conn,"SELECT * FROM studentprofile   WHERE Email='$email'  AND Password='$password' AND status='Approved'");
	$row=mysqli_fetch_array($res);
 
      if($row['UserType']=='Student')
	{
		$_SESSION['EmailStd'] = $row['Email'];
		header("Location: StudentHome.php");
	}
	  if($row['UserType']=='CourseCreator')
	{
		$_SESSION['EmailCC'] = $row['Email'];
		header("Location: ManagePrograms.php");
	}

	else{
	?>
        <script>alert('error you have entered wrong information.');</script>
		<?php
		
 }     
 
} 
?>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>SkillHub</title>

<!-- Bootstrap -->
<link rel="stylesheet" href="css/bootstrap.css">


</head>
<body>
<nav class="navbar navbar-inverse">
  <div class="container-fluid"> 
    
    <div class="navbar-header">
      
       </div>
    
    <?php include("include/GenNev.php"); ?>
    <!-- /.navbar-collapse --> 
  </div>
  <!-- /.container-fluid --> 
</nav>
  <div class="container">
    <div class="row">
      <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 hidden-xs">
        <div>
<form method="post" >
  
  <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">&nbsp;&nbsp;(Student,CourseCreator)  Log-in </h4>
         
        </div>
        <div class="modal-body">
               <div class="form-group">
                  <label for="usr">Email </label>
                   <div class="input-group">
				   
				   <input type="email" class="form-control" id="usr" name="email" placeholder="Enter Your Email" required />
               </div>
			   </div>
			   
			   
			   <div class="form-group">
                  <label for="pwd" >Password</label>
                  <div class="input-group">
				   
				   <input type="password" class="form-control" id="pwd" name="password" placeholder="Enter Your Password" required />
               </div>
			   </div>
			 
			 
			 
			 
			   
			   <div class="modal-footer">
          <div class="row"> 
              <div class="col-md-12 "> 
					<button id="singlebutton" name="login" class="btn btn-primary">Login</button>
					  
			       
		  		
		     </div>
		  
         </div>
      
              </div>
   
</form>
</div>
      </div>
    </div>
    
  </div>








 

</body>
</html>